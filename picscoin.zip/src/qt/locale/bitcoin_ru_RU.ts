<TS language="ru_RU" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>$Right-click to edit address or label</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Создать новый адрес</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Скопировать текущий выбранный адрес в буфер обмена системы</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Удалить выбранный адрес из списка</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Экспортировать данные текущей вкладки в файл</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>Экспортировать</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Выбрать адрес для отправки монет</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Выбрать адрес для получения монет</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>В&amp;ыбрать</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>Адреса отправки</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>Адреса получения</translation>
    </message>
    <message>
        <source>These are your Picscoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Это ваши Picscoin адреса для отправки платежа. Всегда проверяйте сумму и адрес получателя перед отправкой платежа.</translation>
    </message>
    <message>
        <source>These are your Picscoin addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>Это ваши Picscoin адреса для получения платежей. Настоятельно рекомендуем использовать новые адреса для получения каждой транзакции.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;Копировать адрес</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>Копировать &amp;метку</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Редактировать</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>Экспортировать список адресов</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Экспорт не удался</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <translation>Произошла ошибка при попытке сохранения списка адресов в %1. Пожалуйста попробуйте позже.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Метка</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(нет метки)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Ввод пароля</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Введите пароль</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Новый пароль</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Повторите новый пароль</translation>
    </message>
    <message>
        <source>Show password</source>
        <translation>Отобразить пароль</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Введите новый пароль для кошелька.&lt;br/&gt; Пожалуйста используйте пароль из &lt;b&gt; десяти или более произвольных символов&lt;/b&gt;, или &lt;b&gt;восемь или боле слов&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Зашифровать бумажник</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Эта операция требует вашего пароля для разблокировки бумажника</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Разблокировать бумажник</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Эта операция требует пароль от вашего кошелька для его расшифровки.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Расшифровать бумажник</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Изменить пароль</translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase to the wallet.</source>
        <translation>Введите старый и новый пароль для кошелька.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Подтвердите шифрование бумажника</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR PICSCOINS&lt;/b&gt;!</source>
        <translation>Внимание: если вы зашифруете ваш кошелек и потеряете ваш пароль, то вы &lt;b&gt;ПОТЕРЯЕТЕ ВСЕ ВАШИ БИТКОЙНЫ&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Вы уверены, что вы хотите зашифровать ваш кошелек?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Бумажник зашифрован</translation>
    </message>
    <message>
        <source>%1 will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your picscoins from being stolen by malware infecting your computer.</source>
        <translation>%1 закроется сейчас для завершения процесса шифрования. Запомните что шифрование вашего кошелька не сможет полностью защитить ваши Picscoinы от кражи при помощи вредоносного ПО, заразившего ваш компьютер.</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>ВАЖНО: любые предыдущие резервные копия вашего кошелька, выполненные вами, необходимо заменить новым сгенерированным, зашифрованным файлом кошелька. В целях безопасности, предыдущие резервные копии незашифрованного файла кошелька утратят пригодность после начала использования нового зашифрованного кошелька.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Шифрование кошелька завершилось неудачно.</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Шифрование кошелька завершилось неудачно из-за внутренней ошибки. Ваш кошелек не был зашифрован.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Ошибка разблокировки кошелька</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Пароль, введенный при шифровании кошелька, некорректен.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Расшифровка кошелька завершилась неудачно.</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Пароль для кошелька был успешно изменен.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Внимание: клавиша CapsLock включена!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation>IP / маска подсети</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation>Заблокировано до</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Подписать &amp;сообщение...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Синхронизация с сетью...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Обзор</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Узел</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Отобразить общий обзор кошелька</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Транзакции</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Просмотр истории транзакций</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>В&amp;ыход</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Выйти</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>&amp;О программе %1</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation>Показать информацию о %1</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>О библиотеке &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Показать информацию о библиотеке Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Опции...</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation>Изменить опции конфигурации для %1</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Зашифровать кошелёк</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Создать резервную копию бумажника</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Изменить пароль...</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>&amp;Адреса для отправки...</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>&amp;Адреса для получения...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>Открыть &amp;URI...</translation>
    </message>
    <message>
        <source>Click to disable network activity.</source>
        <translation>Нажмите для отключения взаимодействия с сетью.</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <translation>Взаимодействие с сетью отключено.</translation>
    </message>
    <message>
        <source>Click to enable network activity again.</source>
        <translation>Нажмите для включения взаимодействия с сетью.</translation>
    </message>
    <message>
        <source>Syncing Headers (%1%)...</source>
        <translation>Синхронизация заголовков (%1%)...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Реиндексация блоков на диске...</translation>
    </message>
    <message>
        <source>Send coins to a Picscoin address</source>
        <translation>Послать средства на Picscoin адрес</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Выполнить резервное копирование кошелька в другом месте расположения</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Изменить пароль, используемый для шифрования кошелька</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>&amp;Окно отладки</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Открыть консоль отладки и диагностики</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;Проверить сообщение...</translation>
    </message>
    <message>
        <source>Picscoin</source>
        <translation>Picscoin Core</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Кошелек</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Отправить</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;Получить</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Показать / Спрятать</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Показать или скрыть главное окно</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Зашифровать приватные ключи, принадлежащие вашему кошельку</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Файл</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Настройки</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Помощь</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>Опции командной строки</translation>
    </message>
    <message>
        <source>Indexing blocks on disk...</source>
        <translation>Выполняется индексирование блоков на диске...</translation>
    </message>
    <message>
        <source>Processing blocks on disk...</source>
        <translation>Выполняется обработка блоков на диске...</translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>Выполнено %1</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Последний полученный блок был сгенерирован %1 назад.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Готов</translation>
    </message>
    <message>
        <source>Connecting to peers...</source>
        <translation>Подключение к пирам...</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation>Дата: %1
</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation>Объем: %1
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation>Тип: %1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation>Ярлык: %1
</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Входящая транзакция</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Кошелек &lt;b&gt;зашифрован&lt;/b&gt; и сейчас &lt;b&gt;разблокирован&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Кошелек &lt;b&gt;зашифрован&lt;/b&gt; и сейчас &lt;b&gt;заблокирован&lt;/b&gt;</translation>
    </message>
    <message>
        <source>A fatal error occurred. Picscoin can no longer continue safely and will quit.</source>
        <translation>Произошла критическая ошибка. Picscoin больше не может продолжать безопасную работу и будет закрыт.</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Quantity:</source>
        <translation>Количество:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Байтов:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Количество:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Комиссия:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>После комиссии:</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Подтверждения</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Подтвержденные</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Копировать адрес</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Копировать метку</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Копировать сумму</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Копировать ID транзакции</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Копировать количество</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>да</translation>
    </message>
    <message>
        <source>no</source>
        <translation>нет</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(нет метки)</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Изменить адрес</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Адрес</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Новый адрес получения</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Новый адрес отправки</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Изменить адрес получения</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Изменить адрес отправки</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Невозможно разблокировать кошелек.</translation>
    </message>
    </context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>Будет создана новая директория данных.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Невозможно создать директорию данных здесь.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>версия</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation>Около %1</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Опции командной строки</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Использование:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>Опции командной строки</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: %u)</source>
        <translation>Выбрать директорию данных при запуске (по умолчанию: %u)</translation>
    </message>
    <message>
        <source>Set language, for example "de_DE" (default: system locale)</source>
        <translation>Задать язык, к примеру, "de_DE" (по умолчанию: язык системы)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>Запускать свернутым</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: %u)</source>
        <translation>Отображать начальный экран во время запуска (значение по умолчанию: %u)</translation>
    </message>
    <message>
        <source>Reset all settings changed in the GUI</source>
        <translation>Выполнить сброс всех измененных настроек в GUI-интерфейсе</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Добро пожаловать</translation>
    </message>
    <message>
        <source>Welcome to %1.</source>
        <translation>Добро пожаловать в %1.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Использовать стандартную директорию данных</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Использовать пользовательскую директорию данных</translation>
    </message>
    <message>
        <source>Picscoin</source>
        <translation>Picscoin Core</translation>
    </message>
    <message>
        <source>At least %1 GB of data will be stored in this directory, and it will grow over time.</source>
        <translation>Как минимум %1 ГБ данных будет сохранен в эту директорию. Со временем размер будет увеличиваться.</translation>
    </message>
    <message>
        <source>Approximately %1 GB of data will be stored in this directory.</source>
        <translation>Приблизительно %1 ГБ данных будет сохранено в эту директорию.</translation>
    </message>
    <message>
        <source>The wallet will also be stored in this directory.</source>
        <translation>Кошелек также будет сохранен в эту директорию.</translation>
    </message>
    <message>
        <source>Error: Specified data directory "%1" cannot be created.</source>
        <translation>Ошибка: невозможно создать указанную директорию данных "%1".</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Number of blocks left</source>
        <translation>Количество оставшихся блоков</translation>
    </message>
    <message>
        <source>Unknown...</source>
        <translation>Неизвестно...</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Прогресс</translation>
    </message>
    <message>
        <source>calculating...</source>
        <translation>выполняется вычисление...</translation>
    </message>
    <message>
        <source>Estimated time left until synced</source>
        <translation>Расчетное время, оставшееся до синхронизации</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Спрятать</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>Открыть URI</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Опции</translation>
    </message>
    <message>
        <source>Automatically start %1 after logging in to the system.</source>
        <translation>Автоматически запускать %1 после входа в систему.</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>Размер кеша &amp;базы данных</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>МБ</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>IP-адрес прокси-сервера (к примеру, IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Hide the icon from the system tray.</source>
        <translation>Убрать значок с области уведомлений.</translation>
    </message>
    <message>
        <source>&amp;Hide tray icon</source>
        <translation>&amp;Спрятать иконку в трее</translation>
    </message>
    <message>
        <source>Open Configuration File</source>
        <translation>Открыть файл конфигурации</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Сбросить все опции клиента к значениям по умолчанию.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>&amp;Сбросить опции</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Сеть</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>К&amp;ошелёк</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>Эксперт</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Пробросить порт через &amp;UPnP</translation>
    </message>
    <message>
        <source>Connect to the Picscoin network through a SOCKS5 proxy.</source>
        <translation>Подключится к сети Picscoin через SOCKS5 прокси.</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS5 proxy (default proxy):</source>
        <translation>&amp;Выполнить подключение через прокси-сервер SOCKS5 (прокси-сервер по умолчанию):</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>IP прокси:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Порт:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Порт прокси: (напр. 9050)</translation>
    </message>
    <message>
        <source>IPv4</source>
        <translation>IPv4</translation>
    </message>
    <message>
        <source>IPv6</source>
        <translation>IPv6</translation>
    </message>
    <message>
        <source>Tor</source>
        <translation>Tor</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Окно</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Отобразить только значок в области уведомлений после сворачивания окна.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;ОК</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Отмена</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Подтвердить сброс опций</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>Для активации изменений необходим перезапуск клиента.</translation>
    </message>
    <message>
        <source>Client will be shut down. Do you want to proceed?</source>
        <translation>Клиент будет закрыт. Продолжить далее?</translation>
    </message>
    <message>
        <source>Configuration options</source>
        <translation>Опции конфигурации</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <source>The configuration file could not be opened.</source>
        <translation>Невозможно открыть файл конфигурации.</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>Это изменение потребует перезапуск клиента.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>Введенный адрес прокси-сервера недействителен.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Immature:</source>
        <translation>Незрелые:</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation>Балансы</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Всего:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Ваш текущий баланс:</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation>Ваш текущий баланс (только чтение):</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation>Последние транзакции</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation>Ошибка связи с %1: %2</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>Неправильный ответ от сервера %1</translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation>Оплата подтверждена</translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>Node/Service</source>
        <translation>Узел/служба</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Отправлено</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Получено</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Enter a Picscoin address (e.g. %1)</source>
        <translation>Введите биткоин-адрес (напр. %1)</translation>
    </message>
    <message>
        <source>%1 d</source>
        <translation>%1 д</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 ч</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 м</translation>
    </message>
    <message>
        <source>%1 s</source>
        <translation>%1 с</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Н/Д</translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 и %2</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1  Б</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1  КБ</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1  МБ</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 ГБ</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>неизвестно</translation>
    </message>
</context>
<context>
    <name>QObject::QObject</name>
    <message>
        <source>Error: Specified data directory "%1" does not exist.</source>
        <translation>Ошибка: указанная директория данных "%1" не существует.</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation>Ошибка: %1</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;Сохранить изображение...</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>&amp;Копировать изображение</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>Сохранить QR-код</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>PNG Картинка (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>Н/Д</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Версия клиента</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>Окно отладки</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Сеть</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Название</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Количество соединений</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Текущее количество блоков</translation>
    </message>
    <message>
        <source>Memory Pool</source>
        <translation>Пул памяти</translation>
    </message>
    <message>
        <source>Current number of transactions</source>
        <translation>Текущее количество транзакций</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation>Использование памяти</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Сбросить</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Получено</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Отправлено</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>&amp;Пиры</translation>
    </message>
    <message>
        <source>Banned peers</source>
        <translation>Заблокированные пиры</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>Decrease font size</source>
        <translation>Уменьшить размер шрифта</translation>
    </message>
    <message>
        <source>Increase font size</source>
        <translation>Увеличить размер шрифта</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Открыть</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Консоль</translation>
    </message>
    <message>
        <source>1 &amp;hour</source>
        <translation>1 &amp;час</translation>
    </message>
    <message>
        <source>1 &amp;day</source>
        <translation>1 &amp;день</translation>
    </message>
    <message>
        <source>1 &amp;week</source>
        <translation>1 &amp;неделя</translation>
    </message>
    <message>
        <source>1 &amp;year</source>
        <translation>1 &amp;год</translation>
    </message>
    <message>
        <source>Type %1 for an overview of available commands.</source>
        <translation>Ввести %1 для обзора доступных команд.</translation>
    </message>
    <message>
        <source>never</source>
        <translation>никогда</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Нет</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Неизвестно</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Очистить все поля формы.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Отчистить</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>Отобразить выбранный запрос (выполняет то же, что и двойной щелчок на записи)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Показать</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>Удалить выбранные записи со списка</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Copy URI</source>
        <translation>Копировать URI</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Копировать метку</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>Копировать сообщение</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Копировать сумму</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR-код</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;Сохранить изображение...</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>Информация о платеже</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Метка</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Сообщение</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>Ошибка преобразования URI в QR-код.</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Метка</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Сообщение</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(нет метки)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(нет сообщений)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Отправить монеты</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>выбрано автоматически</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Количество:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Байтов:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Количество:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Комиссия:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>После комиссии:</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Комиссия за транзакцию:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Выбрать...</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Спрятать</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation>Рекомендованное значение:</translation>
    </message>
    <message>
        <source>Custom:</source>
        <translation>Пользовательское значение:</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Отправить нескольким получателям сразу</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Очистить все поля формы.</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Баланс:</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Копировать количество</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Копировать сумму</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>Вы действительно хотите выполнить отправку?</translation>
    </message>
    <message>
        <source>or</source>
        <translation>или</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Подтвердить отправку монет</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Сумма оплаты должна быть больше 0.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>Количество превышает ваш баланс.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>Создание транзакции завершилось неудачей!</translation>
    </message>
    <message>
        <source>The transaction was rejected with the following reason: %1</source>
        <translation>Транзакция была отменена по следующей причине: %1</translation>
    </message>
    <message>
        <source>A fee higher than %1 is considered an absurdly high fee.</source>
        <translation>Комиссия более чем в %1 считается абсурдно высокой.</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(нет метки)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>Choose previously used address</source>
        <translation>Выбрать предыдущий использованный адрес</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Вставить адрес из буфера обмена</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>Удалить эту запись</translation>
    </message>
    <message>
        <source>Use available balance</source>
        <translation>Использовать доступный баланс</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Сообщение:</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Выполнить оплату в пользу:</translation>
    </message>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    <message>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>%1 is shutting down...</source>
        <translation>%1 завершает работу...</translation>
    </message>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Choose previously used address</source>
        <translation>Выбрать предыдущий использованный адрес</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Вставить адрес из буфера обмена</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Подпись</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Скопировать текущую подпись в буфер обмена системы</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>Введенный адрес недействителен.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>Необходимо проверить адрес и выполнить повторную попытку.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>Разблокирование кошелька было отменено.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>Сообщение подписано.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>Невозможно расшифровать подпись.</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    </context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Источник</translation>
    </message>
    <message>
        <source>From</source>
        <translation>От</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>неизвестно</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Сообщение</translation>
    </message>
    </context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Details for %1</source>
        <translation>Детальная информация по %1</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Метка</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(нет метки)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Статус транзакции. Для отображения количества подтверждений необходимо навести курсор на это поле.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Дата и время получения транзакции.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Тип транзакции.</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Increase transaction fee</source>
        <translation>Увеличить комиссию за транзакцию</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Копировать адрес</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Копировать метку</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Копировать сумму</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Копировать ID транзакции</translation>
    </message>
    <message>
        <source>Copy full transaction details</source>
        <translation>Копировать все детали транзакции</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>Отобразить детали транзакции</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Метка</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ИН</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Экспорт не удался</translation>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation>При попытке сохранения истории транзакций в %1 произошла ошибка.</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>Экспорт выполнен успешно</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation>Историю транзакций было успешно сохранено в %1.</translation>
    </message>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>Отправить монеты</translation>
    </message>
    <message>
        <source>Increasing transaction fee failed</source>
        <translation>Увеличение комиссии за транзакцию завершилось неудачей</translation>
    </message>
    <message>
        <source>Do you want to increase the fee?</source>
        <translation>Желаете увеличить комиссию?</translation>
    </message>
    <message>
        <source>Current fee:</source>
        <translation>Текущее значение комиссии</translation>
    </message>
    <message>
        <source>Increase:</source>
        <translation>Увеличить</translation>
    </message>
    <message>
        <source>New fee:</source>
        <translation>Новое значение комиссии:</translation>
    </message>
    <message>
        <source>Can't sign transaction.</source>
        <translation>Невозможно подписать транзакцию</translation>
    </message>
    <message>
        <source>Could not commit transaction</source>
        <translation>Не удалось выполнить транзакцию</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>Экспортировать</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Экспортировать данные в текущей вкладке в файл</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>Создать резервную копию кошелька</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>Данные кошелька (*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>Создание резервной копии кошелька завершилось неудачей</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>При попытке сохранения данных кошелька в %1 произошла ошибка.</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>Резервное копирование выполнено успешно</translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>Данные кошелька были успешно сохранены в %1.</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>Опции:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Указать директорию данных</translation>
    </message>
    <message>
        <source>Error: A fatal internal error occurred, see debug.log for details</source>
        <translation>Ошибка: произошла критическая внутренняя ошибка, для получения деталей см. debug.log</translation>
    </message>
    <message>
        <source>Unable to start HTTP server. See debug log for details.</source>
        <translation>Невозможно запустить HTTP-сервер. Для получения более детальной информации необходимо обратиться к журналу отладки.</translation>
    </message>
    <message>
        <source>Picscoin Core</source>
        <translation>Picscoin Core</translation>
    </message>
    <message>
        <source>The %s developers</source>
        <translation>Разработчики %s</translation>
    </message>
    <message>
        <source>%d of last 100 blocks have unexpected version</source>
        <translation>%d из последних 100 блоков имеют неожиданную версию</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>Опции соединения:</translation>
    </message>
    <message>
        <source>Copyright (C) %i-%i</source>
        <translation>Авторское право (©) %i-%i</translation>
    </message>
    <message>
        <source>Error loading %s</source>
        <translation>Ошибка загрузки %s</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet corrupted</source>
        <translation>Ошибка загрузки %s: кошелек поврежден</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet requires newer version of %s</source>
        <translation>Ошибка загрузки %s: кошелек требует более поздней версии %s</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Ошибка: место на диске заканчивается!</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>Выполняется импорт...</translation>
    </message>
    <message>
        <source>Loading P2P addresses...</source>
        <translation>Выполняется загрузка P2P-адресов...</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>Недоступно достаточного количества дескрипторов файла.</translation>
    </message>
    <message>
        <source>Only connect to nodes in network &lt;net&gt; (ipv4, ipv6 or onion)</source>
        <translation>Подключаться только к узлам в сети &lt;net&gt; (ipv4, ipv6 или onion)</translation>
    </message>
    <message>
        <source>Print this help message and exit</source>
        <translation>Распечатать это сообщение справки и выйти</translation>
    </message>
    <message>
        <source>Print version and exit</source>
        <translation>Распечатать версию и выйти</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>Указать файл кошелька (в пределах директории данных)</translation>
    </message>
    <message>
        <source>Unsupported argument -debugnet ignored, use -debug=net.</source>
        <translation>Неподдерживаемый аргумент -debugnet пропущен, необходимо использовать -debug=net.</translation>
    </message>
    <message>
        <source>Unsupported argument -tor found, use -onion.</source>
        <translation>Обнаружен неподдерживаемый аргумент -tor, необходимо использовать -onion.</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>Опции кошелька:</translation>
    </message>
    <message>
        <source>Whitelisted peers cannot be DoS banned and their transactions are always relayed, even if they are already in the mempool, useful e.g. for a gateway</source>
        <translation>bitcoin-core</translation>
    </message>
    <message>
        <source>(default: %u)</source>
        <translation>(значение по умолчанию: %u)</translation>
    </message>
    <message>
        <source>Connect through SOCKS5 proxy</source>
        <translation>Выполнить подключение через прокси-сервер SOCKS5</translation>
    </message>
    <message>
        <source>Error reading from database, shutting down.</source>
        <translation>Ошибка чтения с базы данных, выполняется закрытие.</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>Подписание транзакции завершилось неудачей</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <source>Do not keep transactions in the mempool longer than &lt;n&gt; hours (default: %u)</source>
        <translation>Do not keep transactions in the mempool longer than &lt;n&gt; hours (default: %u)</translation>
    </message>
    <message>
        <source>(default: %s)</source>
        <translation>(значение по умолчанию: %s)</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Выполняется загрузка кошелька...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Невозможно выполнить переход на более раннюю версию кошелька</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Выполняется повторное сканирование...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Загрузка завершена</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
</context>
</TS>