<TS language="uz@Cyrl" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Манзил ёки ёрлиқни таҳрирлаш учун икки марта босинг</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Янги манзил яратинг</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Янги</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Жорий танланган манзилни тизим вақтинчалик хотирасига нусха кўчиринг</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Нусха олиш</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Ёпиш</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Жорий танланган манзилни рўйхатдан ўчириш</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Жорий ички ойна ичидаги маълумотларни файлга экспорт қилиш</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Экспорт</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Ўчириш</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Махфий сўз ойнаси</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Махфий сузни киритинг</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Янги махфий суз</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Янги махфий сузни такрорланг</translation>
    </message>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>&amp;Хабар ёзиш...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Тармоқ билан синхронланмоқда...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Кўриб чиқиш</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Улам</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Ҳамённинг умумий кўринишини кўрсатиш</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Пул ўтказмалари</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Пул ўтказмалари тарихини кўриш</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>Ч&amp;иқиш</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Иловадан чиқиш</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>&amp;Qt ҳақида</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Qt ҳақидаги маълумотларни кўрсатиш</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Мосламалар...</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>Ҳамённи &amp;кодлаш...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>Ҳамённи &amp;заҳиралаш...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>Махфий сўзни &amp;ўзгартириш...</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>&amp;Жўнатилувчи манзиллар...</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>&amp;Қабул қилувчи манзиллар...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>Интернет манзилни очиш</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Дискдаги блоклар қайта индексланмоқда...</translation>
    </message>
    <message>
        <source>Send coins to a Picscoin address</source>
        <translation>Тангаларни Picscoin манзилига жўнатиш</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Ҳамённи бошқа манзилга заҳиралаш</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Паролни ўзгартириш ҳамённи кодлашда фойдаланилади</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>&amp;Носозликни ҳал қилиш ойнаси</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Носозликни ҳал қилиш ва ташхис терминали</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>Хабарни &amp;тасдиқлаш...</translation>
    </message>
    <message>
        <source>Picscoin</source>
        <translation>Picscoin</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Ҳамён</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Жўнатиш</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;Қабул қилиш</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Кўрсатиш / Яшириш</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Асосий ойнани кўрсатиш ёки яшириш</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Ҳамёнингизга тегишли махфий калитларни кодлаш</translation>
    </message>
    <message>
        <source>Sign messages with your Picscoin addresses to prove you own them</source>
        <translation>Picscoin манзилидан унинг эгаси эканлигингизни исботлаш учун хабарлар ёзинг</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Picscoin addresses</source>
        <translation>Хабарларни махсус Picscoin манзилларингиз билан ёзилганлигига ишонч ҳосил қилиш учун уларни тасдиқланг</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Файл</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp; Созламалар</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ёрдам</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Ички ойналар асбоблар панели</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and picscoin: URIs)</source>
        <translation>Тўловлар (QR кодлари ва picscoin ёрдамида яратишлар: URI’лар) сўраш</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>Фойдаланилган жўнатилган манзиллар ва ёрлиқлар рўйхатини кўрсатиш</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>Фойдаланилган қабул қилинган манзиллар ва ёрлиқлар рўйхатини кўрсатиш</translation>
    </message>
    <message>
        <source>Open a picscoin: URI or payment request</source>
        <translation>Picscoin’ни очиш: URI ёки тўлов сўрови</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>&amp;Буйруқлар сатри мосламалари</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Picscoin network</source>
        <translation><numerusform>%n та Picscoin тармоғига фаол уланиш мавжуд</numerusform></translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 орқада</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Сўнги қабул қилинган блок %1 олдин яратилган.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Бундан кейинги пул ўтказмалари кўринмайдиган бўлади.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Хатолик</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Диққат</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Маълумот</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Янгиланган</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Банд қилинмоқда...</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Жўнатилган операция</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Кирувчи операция</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Ҳамён &lt;b&gt;кодланган&lt;/b&gt; ва вақтинча &lt;b&gt;қулфдан чиқарилган&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Ҳамён &lt;b&gt;кодланган&lt;/b&gt; ва вақтинча &lt;b&gt;қулфланган&lt;/b&gt;</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Quantity:</source>
        <translation>Сони:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Байт:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Миқдори:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Солиқ:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Ахлат қутиси:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Солиқдан сўнг:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Ўзгартириш:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>барчасини танаш (бекор қилиш)</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>Дарахт усулида</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>Рўйхат усулида</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Миқдори</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Сана</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Тасдиқлашлар</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Тасдиқланди</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Манзилларни таҳрирлаш</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Ёрлик</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>Ёрлиқ ушбу манзилар рўйхати ёзуви билан боғланган</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>Манзил ушбу манзиллар рўйхати ёзуви билан боғланган. Уни фақат жўнатиладиган манзиллар учун ўзгартирса бўлади.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Манзил</translation>
    </message>
    </context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>Янги маълумотлар директорияси яратилади.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>номи</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>Директория аллақачон мавжуд. Агар бу ерда янги директория яратмоқчи бўлсангиз, %1 қўшинг.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>Йўл аллақачон мавжуд. У директория эмас.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Маълумотлар директориясини бу ерда яратиб бўлмайди..</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>версияси</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-bit)</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Буйруқлар сатри мосламалари</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Фойдаланиш:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>буйруқлар қатори орқали мослаш</translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Хуш келибсиз</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Стандарт маълумотлар директориясидан фойдаланиш</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Бошқа маълумотлар директориясида фойдаланинг:</translation>
    </message>
    <message>
        <source>Picscoin</source>
        <translation>Picscoin</translation>
    </message>
    <message>
        <source>Error: Specified data directory "%1" cannot be created.</source>
        <translation>Хато: кўрсатилган "%1" маълумотлар директориясини яратиб бўлмайди.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Хатолик</translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>Шакл</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Сўнгги блок вақти</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>URI ни очиш</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>URL файлдан тўлов сўровларини очиш</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>Тўлов сўрови файлини танлаш</translation>
    </message>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Танламалар</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Асосий</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>&amp;Маълумотлар базаси кеши</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>МБ</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>Мавзуларни &amp;тўғрилаш скрипти миқдори</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>Прокси IP манзили (масалан: IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>Тармоқ</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>Ҳамён</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>Прокси &amp;IP рақами:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Порт:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Прокси порти (e.g. 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Ойна</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Ойна йиғилгандан сўнг фақат трэй нишончаси кўрсатилсин.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>Манзиллар панели ўрнига трэйни &amp;йиғиш</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>Ёпишда й&amp;иғиш</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;Кўрсатиш</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>Фойдаланувчи интерфейси &amp;тили:</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>Миқдорларни кўрсатиш учун &amp;қисм:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Бекор қилиш</translation>
    </message>
    <message>
        <source>default</source>
        <translation>стандарт</translation>
    </message>
    <message>
        <source>none</source>
        <translation>йўқ</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Тасдиқлаш танловларини рад қилиш</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>Ўзгаришлар амалга ошиши учун мижозни қайта ишга тушириш талаб қилинади.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Хатолик</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>Ушбу ўзгариш мижозни қайтадан ишга туширишни талаб қилади.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>Келтирилган прокси манзили ишламайди.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Шакл</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Picscoin network after a connection is established, but this process has not completed yet.</source>
        <translation>Кўрсатилган маълумот эскирган бўлиши мумкин. Ҳамёнингиз алоқа ўрнатилгандан сўнг Picscoin тармоқ билан автоматик тарзда синхронланади, аммо жараён ҳалигача тугалланмади.</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation>Фақат кўришга</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>Мавжуд:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>Жорий сарфланадиган балансингиз</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>Кутилмоқда:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>Жами ўтказмалар ҳозиргача тасдиқланган ва сафланадиган баланс томонга ҳали ҳам ҳисобланмади</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Тайёр эмас:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Миналаштирилган баланс ҳалигача тайёр эмас</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation>Баланслар</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Жами:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Жорий умумий балансингиз</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation>Жорий балансингиз фақат кўринадиган манзилларда</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation>Сарфланадиган:</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation>Сўнгги пул ўтказмалари</translation>
    </message>
    <message>
        <source>Unconfirmed transactions to watch-only addresses</source>
        <translation>Тасдиқланмаган ўтказмалар-фақат манзилларини кўриш</translation>
    </message>
    <message>
        <source>Current total balance in watch-only addresses</source>
        <translation>Жорий умумий баланс фақат кўринадиган манзилларда</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <translation>Фойдаланувчи вакил</translation>
    </message>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Миқдори</translation>
    </message>
    <message>
        <source>Enter a Picscoin address (e.g. %1)</source>
        <translation>Picscoin манзилини киритинг (масалан.  %1)</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 д</translation>
    </message>
    <message>
        <source>%1 s</source>
        <translation>%1 с</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Йўқ</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Тўғри келмайди</translation>
    </message>
    <message>
        <source>%1 ms</source>
        <translation>%1 мс</translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 ва %2</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 Б</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 КБ</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 МБ</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 ГБ</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>Номаълум</translation>
    </message>
</context>
<context>
    <name>QObject::QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>Тўғри келмайди</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Мижоз номи</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Маълумот</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>Тузатиш ойнаси</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Асосий</translation>
    </message>
    <message>
        <source>Using BerkeleyDB version</source>
        <translation>Фойдаланилаётган BerkeleyDB версияси</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Бошланиш вақти</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Тармоқ</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Ном</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>&amp;Уламлар</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation>Батафсил маълумотларни кўриш учун уламни танланг.</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>Йўналиш</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation>Фойдаланувчи вакил</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Хизматлар</translation>
    </message>
    <message>
        <source>Ban Score</source>
        <translation>Тезликни бан қилиш</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation>Уланиш вақти</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation>Сўнгги жўнатилган</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation>Сўнгги қабул қилинган</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>Ping вақти</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Сўнгги блок вақти</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Очиш</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Терминал</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;Тармоқ трафиги</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Жами</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>Ичига:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>Ташқарига:</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Тузатиш журнали файли</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Терминални тозалаш</translation>
    </message>
    <message>
        <source>via %1</source>
        <translation>%1 орқали</translation>
    </message>
    <message>
        <source>never</source>
        <translation>ҳеч қачон</translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation>Ички йўналиш</translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation>Ташқи йўналиш</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ҳа</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Йўқ</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Номаълум</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp;Миқдор:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Ёрлиқ:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;Хабар:</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>Янги қабул қилинаётган манзил билан боғланган танланадиган ёрлиқ.</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>Ушбу сўровдан тўловларни сўраш учун фойдаланинг. Барча майдонлар &lt;b&gt;мажбурий эмас&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>Хоҳланган миқдор сўрови. Кўрсатилган миқдорни сўраш учун буни бўш ёки ноль қолдиринг.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Шаклнинг барча майдончаларини тозалаш</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Тозалаш</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>Сўралган тўлов тарихи</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>Тўловни &amp;сўраш</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>Танланган сўровни кўрсатиш (икки марта босилганда ҳам бир хил амал бажарилсин)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Кўрсатиш</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>Танланганларни рўйхатдан ўчириш</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Ўчириш</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR Коди</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>Нусҳалаш &amp; Манзил</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>Расмни &amp;сақлаш</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Тангаларни жунат</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>Танга бошқаруви ҳусусиятлари</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>автоматик тарзда танланган</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Кам миқдор</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Сони:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Байт:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Миқдори:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Солиқ:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Солиқдан сўнг:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Ўзгартириш:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>Агар бу фаоллаштирилса, аммо ўзгартирилган манзил бўл ёки нотўғри бўлса, ўзгариш янги яратилган манзилга жўнатилади.</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>Бошқа ўзгартирилган манзил</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Ўтказма тўлови</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Танлов</translation>
    </message>
    <message>
        <source>per kilobyte</source>
        <translation>Хар килобайтига</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation>Тавсия этилган</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Бирданига бир нечта қабул қилувчиларга жўнатиш</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Шаклнинг барча майдончаларини тозалаш</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Ахлат қутиси:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Барчасини &amp; Тозалаш</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Баланс</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Жўнатиш амалини тасдиқлаш</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>Жў&amp;натиш</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>&amp;Миқдори:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>&amp;Тўлов олувчи:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Ёрлиқ:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Олдин фойдаланилган манзилни танла</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>Бу нормал тўлов.</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Клипбоарддан манзилни қўйиш</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Хабар</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Тўлов олувчи:</translation>
    </message>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Choose previously used address</source>
        <translation>Олдин фойдаланилган манзилни танла</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Клипбоарддан манзилни қўйиш</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Имзо</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Барчасини &amp; Тозалаш</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Ушбу ойна операциянинг батафсил таърифини кўрсатади</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>Танламалар:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Маълумотлар директориясини кўрсатинг</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Буйруқлар сатри ва JSON-RPC буйруқларига рози бўлинг</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Демон сифатида орқа фонда ишга туширинг ва буйруқларга рози бўлинг</translation>
    </message>
    <message>
        <source>Picscoin Core</source>
        <translation>Picscoin Core</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>Уланиш кўрсаткичлари:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Маълумот</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>JSON-RPC уланишлари учун фойдаланувчи номи</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Диққат</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>JSON-RPC уланишлари учун парол</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Кам миқдор</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Тўсиқ индекси юкланмоқда...</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Ҳамён юкланмоқда...</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Қайта текшириб чиқилмоқда...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Юклаш тайёр</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Хатолик</translation>
    </message>
</context>
</TS>